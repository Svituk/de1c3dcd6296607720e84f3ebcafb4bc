<?php

////////////////////////////////////////
global $connect;
$k_p_news_result = mysqli_query($connect, "SELECT COUNT(*) as cnt FROM `news`");
$k_p_news_row = mysqli_fetch_assoc($k_p_news_result);
$k_p_news = $k_p_news_row['cnt'];
$k_n_news_result = mysqli_query($connect, "SELECT COUNT(*) as cnt FROM `news` WHERE `time` > '".(time()-86400)."'");
$k_n_news_row = mysqli_fetch_assoc($k_n_news_result);
$k_n_news = $k_n_news_row['cnt'];
if ($k_n_news==0)$k_n_news=NULL;
else $k_n_news = ' <sup><font color=#FF4500>+'.$k_n_news.'</font></sup>';
echo "<strong><a class='apicms_menu_s' href='/modules/all_news.php' > <img src='/design/styles/".htmlspecialchars($api_design)."/menu/news.png' alt=''> Новости <span style='float:right'> <small>".$k_p_news." ".$k_n_news."</small> </span></strong></a>";
////////////////////////////////////////
echo '<div class="apicms_menu">Общение и обсуждения</div>';
////////////////////////////////////////
$k_p_chat_result = mysqli_query($connect, "SELECT COUNT(*) as cnt FROM `mini_chat`");
$k_p_chat_row = mysqli_fetch_assoc($k_p_chat_result);
$k_p_chat = $k_p_chat_row['cnt'];
$k_n_chat_result = mysqli_query($connect, "SELECT COUNT(*) as cnt FROM `mini_chat` WHERE `time` > '".(time()-86400)."'");
$k_n_chat_row = mysqli_fetch_assoc($k_n_chat_result);
$k_n_chat = $k_n_chat_row['cnt'];
if ($k_n_chat==0)$k_n_chat=NULL;
else $k_n_chat = ' <sup><font color=#FF4500>+'.$k_n_chat.'</font></sup>';
echo "<strong><a class='apicms_menu_s' href='/mini_chat/' > <img src='/design/styles/".htmlspecialchars($api_design)."/menu/mini.png' alt=''> Мини-чат <span style='float:right'> <small>".$k_p_chat." ".$k_n_chat."</small> </span> </strong></a>";
////////////////////////////////////////
$k_p_guest_t_result = mysqli_query($connect, "SELECT COUNT(*) as cnt FROM `guest`");
$k_p_guest_t_row = mysqli_fetch_assoc($k_p_guest_t_result);
$k_p_guest_t = $k_p_guest_t_row['cnt'];
$k_n_guest_t_result = mysqli_query($connect, "SELECT COUNT(*) as cnt FROM `guest` WHERE `time` > '".(time()-86400)."'");
$k_n_guest_t_row = mysqli_fetch_assoc($k_n_guest_t_result);
$k_n_guest_t = $k_n_guest_t_row['cnt'];
if ($k_n_guest_t==0)$k_n_guest_t=NULL;
else $k_n_guest_t = '<sup><font color=#FF4500> +'.$k_n_guest_t.'</font></sup>';
echo "<strong><a class='apicms_menu_s' href='/guest/' > <img src='/design/styles/".htmlspecialchars($api_design)."/menu/guest.png' alt=''> Гостевая <span style='float:right'> <small>".$k_p_guest_t." ".$k_n_guest_t."</small> </span> </strong></a>";
////////////////////////////////////////
$k_p_forum_t_result = mysqli_query($connect, "SELECT COUNT(*) as cnt FROM `api_forum_theme`");
$k_p_forum_t_row = mysqli_fetch_assoc($k_p_forum_t_result);
$k_p_forum_t = $k_p_forum_t_row['cnt'];
$k_n_forum_t_result = mysqli_query($connect, "SELECT COUNT(*) as cnt FROM `api_forum_theme` WHERE `time` > '".(time()-86400)."'");
$k_n_forum_t_row = mysqli_fetch_assoc($k_n_forum_t_result);
$k_n_forum_t = $k_n_forum_t_row['cnt'];
if ($k_n_forum_t==0)$k_n_forum_t=NULL;
else $k_n_forum_t = '<sup><font color=#FF4500> +'.$k_n_forum_t.'</font></sup>';
$k_p_forum_p_result = mysqli_query($connect, "SELECT COUNT(*) as cnt FROM `api_forum_post`");
$k_p_forum_p_row = mysqli_fetch_assoc($k_p_forum_p_result);
$k_p_forum_p = $k_p_forum_p_row['cnt'];
$k_n_forum_p_result = mysqli_query($connect, "SELECT COUNT(*) as cnt FROM `api_forum_post` WHERE `time` > '".(time()-86400)."'");
$k_n_forum_p_row = mysqli_fetch_assoc($k_n_forum_p_result);
$k_n_forum_p = $k_n_forum_p_row['cnt'];
if ($k_n_forum_p==0)$k_n_forum_p=NULL;
else $k_n_forum_p = '<sup><font color=#FF4500> +'.$k_n_forum_p.'</font></sup>';
echo "<strong><a class='apicms_menu_s' href='/api_forum/' > <img src='/design/styles/".htmlspecialchars($api_design)."/menu/forum.png' alt=''> Форум <span style='float:right'> <small>".$k_p_forum_t." ".$k_n_forum_t." / ".$k_p_forum_p." ".$k_n_forum_p."</small> </span> </strong></a>";
include_once 'last_themes.php';
////////////////////////////////////////
$k_p_lib_t_result = mysqli_query($connect, "SELECT COUNT(*) as cnt FROM `api_lib_article`");
$k_p_lib_t_row = mysqli_fetch_assoc($k_p_lib_t_result);
$k_p_lib_t = $k_p_lib_t_row['cnt'];
$k_n_lib_t_result = mysqli_query($connect, "SELECT COUNT(*) as cnt FROM `api_lib_article` WHERE `time` > '".(time()-86400)."'");
$k_n_lib_t_row = mysqli_fetch_assoc($k_n_lib_t_result);
$k_n_lib_t = $k_n_lib_t_row['cnt'];
if ($k_n_lib_t==0)$k_n_lib_t=NULL;
else $k_n_lib_t = '<sup><font color=#FF4500> +'.$k_n_lib_t.'</font></sup>';
$k_p_lib_p_result = mysqli_query($connect, "SELECT COUNT(*) as cnt FROM `api_lib_cat`");
$k_p_lib_p_row = mysqli_fetch_assoc($k_p_lib_p_result);
$k_p_lib_p = $k_p_lib_p_row['cnt'];
$k_n_lib_p_result = mysqli_query($connect, "SELECT COUNT(*) as cnt FROM `api_lib_cat` WHERE `time` > '".(time()-86400)."'");
$k_n_lib_p_row = mysqli_fetch_assoc($k_n_lib_p_result);
$k_n_lib_p = $k_n_lib_p_row['cnt'];
if ($k_n_lib_p==0)$k_n_lib_p=NULL;
else $k_n_lib_p = '<sup><font color=#FF4500> +'.$k_n_lib_p.'</font></sup>';
echo "<strong><a class='apicms_menu_s' href='/api_lib/' > <img src='/design/styles/".htmlspecialchars($api_design)."/menu/library.png' alt=''> Библиотека <span style='float:right'> <small>".$k_p_lib_t." ".$k_n_lib_t." / ".$k_p_lib_p." ".$k_n_lib_p."</small> </span> </strong></a>";

?>