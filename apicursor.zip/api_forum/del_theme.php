<?


/////////////////////////////////////////
$title = 'Удаление';
require_once '../api_core/apicms_system.php';
require_once '../design/styles/'.htmlspecialchars($api_design).'/head.php';
/////////////////////////////////////////
global $connect;
$theme_id = intval($_GET['id']);

if (!isset($user)) header('location: index.php');
$post = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `api_forum_theme` WHERE `id` = '".$theme_id."' LIMIT 1"));
if (isset($user) && $user['id'] == $post['id_user'] or $user['level']==1 or $user['level']==2){
$check_theme = mysqli_query($connect, "SELECT COUNT(*) as cnt FROM `api_forum_theme` WHERE `id` = '".$theme_id."'");
$check_theme_row = mysqli_fetch_assoc($check_theme);
if (isset($_POST['okdel']) && $check_theme_row['cnt']==1){
mysqli_query($connect, "DELETE FROM `api_forum_theme` WHERE `id` = '$theme_id'");
mysqli_query($connect, "DELETE FROM `api_forum_post` WHERE `theme` = '$theme_id'");
header("Location: index.php");
}else{
echo "<div class='erors'>Ошибка удаления</div>\n";
}
/////////////////////////////////////////
echo "<form action='del_theme.php?id=".$theme_id."&ok' method=\"post\">\n";
echo "<div class='content'><center><input type='submit' name='okdel' value='Подтвердить удаление'/></form></center></div>\n";
//////////////////////////////////////////
}
require_once '../design/styles/'.htmlspecialchars($api_design).'/footer.php';
?>