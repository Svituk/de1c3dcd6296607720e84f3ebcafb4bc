<?


////////////////////////////////////////
$title = 'Редактирование темы';
require_once '../api_core/apicms_system.php';
require_once '../design/styles/'.htmlspecialchars($api_design).'/head.php';
////////////////////////////////////////
if (!$user['id']) header('location: /');
global $connect;
$theme_id = intval($_GET['id']);
$setthem = mysqli_fetch_array(mysqli_query($connect, "SELECT * FROM `api_forum_theme` WHERE `id` = '$theme_id' LIMIT 1"));
$check_theme = mysqli_query($connect, "SELECT COUNT(*) as cnt FROM `api_forum_theme` WHERE `id` = '".$theme_id."'");
$check_theme_row = mysqli_fetch_assoc($check_theme);
if (isset($_GET['id']) && ($user['id'] == $setthem['id_user'] or $user['level']==1 or $user['level']==2) && $check_theme_row['cnt']==1){
///////////////////////////////////
if (isset($_POST['save']) && ($user['id'] == $setthem['id_user'] or $user['level']==1 or $user['level']==2)){
///////////////////////////////////

$nameus = apicms_filter($_POST['name']);
$textus = apicms_filter($_POST['text']);

mysqli_query($connect, "UPDATE `api_forum_theme` SET `name` = '$nameus', `text` = '$textus'  WHERE `id` = '$theme_id' LIMIT 1");

///////////////////////////////////
header("Location: /api_forum/edit_theme.php?id=".$theme_id."");
echo '<div class="erors">Изменения внесены в тему</div>';
}
////////////////////////////////////////
echo "<form method='post' action='?id=".$theme_id."&ok'>";
///////////////////////////////////
echo '<div class="apicms_subhead">';
echo "Название темы: </br> <input type='text' name='name' value='".htmlentities($setthem['name'], ENT_QUOTES, 'UTF-8')."' style='width:95%;' /><br />";
echo '</div>';
///////////////////////////////////
echo "<div class='apicms_subhead'>";
echo 'Сообщение темы:</br><textarea name="text" cols="17" rows="3" style="width:95%;" >'.htmlspecialchars($setthem['text']).'</textarea><br />';
echo '</div>';
echo "<div class='apicms_subhead'><center><input type='submit' name='save' value='Обновить информацию' style='width:95%;' /></center></div>";
}else{
echo "<div class='erors'><center>Извините, параметры не верны!</center></div>";
}
////////////////////////////////////////
require_once '../design/styles/'.htmlspecialchars($api_design).'/footer.php';
?>