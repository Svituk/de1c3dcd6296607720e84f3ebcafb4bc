<?


////////////////////////////////////////
$title = 'Форум - Создание новой темы';
require_once '../api_core/apicms_system.php';
require_once '../design/styles/'.htmlspecialchars($api_design).'/head.php';
////////////////////////////////////////
global $connect;
if (isset($_GET['id']))$subforum_id = intval($_GET['id']);
$check_subforum = mysqli_query($connect, "SELECT COUNT(*) as cnt FROM `api_forum_subforum` WHERE `id` = '".$subforum_id."'");
$check_subforum_row = mysqli_fetch_assoc($check_subforum);
if (isset($_GET['id']) && $check_subforum_row['cnt']==1){
if ($user){
if (isset($_POST['save'])){
if (isset($_POST['name']) && isset($_POST['text']) && strlen($_POST['name'])>10 && strlen($_POST['text'])>50){
$my_theme_name = apicms_filter($_POST['name']);
$my_theme_text = apicms_filter($_POST['text']);
mysqli_query($connect, "INSERT INTO `api_forum_theme` (name, text, id_user, time, subforum) values ('$my_theme_name', '$my_theme_text', '".intval($user['id'])."', '$time', '$subforum_id')");
}
///////////////////////////////////
echo '<div class="erors"><center>Тема успешно создана</center></div>';
header("Location: all_theme.php?id=$subforum_id");
}
////////////////////////////////////////
echo "<form method='post' action='?ok&id=$subforum_id'>\n";
echo '<div class="apicms_dialog">';
echo "Название темы:  мин. 10 симв.</br> <input type='text' name='name' value=''  /><br />\n";
echo "Текст обращения: мин. 50 симв.</br><textarea name='text'></textarea><br />\n";
echo '</div>';
///////////////////////////////////
echo "<div class='apicms_subhead'><input type='submit' name='save' value='Создать новую тему' /></div>\n";
}else{
echo "<div class='erors'>У вас нет прав создавать темы</div>\n";
}
}else{
echo "<div class='erors'>Ошибка раздела</div>\n";
}
////////////////////////////////////////
require_once '../design/styles/'.htmlspecialchars($api_design).'/footer.php';
?>