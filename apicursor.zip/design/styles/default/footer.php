<?php

include_once 'api_core/ads_down.php';
global $connect;
$refr = apicms_generate(6);
$reg_count_result = mysqli_query($connect, "SELECT id FROM `users`");
$reg_count = mysqli_num_rows($reg_count_result);
$tm_on = time()-600;
$onsus_result = mysqli_query($connect, "SELECT COUNT(*) as cnt FROM `users` WHERE `activity` > '$tm_on'");
$onsus_row = mysqli_fetch_assoc($onsus_result);
$onsus = $onsus_row['cnt'];
if ($onsus > 0)$onsite = '<img src="/design/styles/'.htmlspecialchars($api_design).'/images/onliner.png"> '.$onsus.'';
else $onsite = 'Никого нет';
$us_last = mysqli_fetch_array(mysqli_query($connect, "select `login`,`id` from `users` ORDER BY id DESC limit 1"));
////////////////////////////////////////
echo '<div class="apicms_footer"><table width="100%"><tr><td width="33%"><center><a href="/modules/all_profiles.php"><img src="/design/styles/'.htmlspecialchars($api_design).'/images/profiles.png"> '.$reg_count.' </a> <a href="/profile.php?id='.$us_last['id'].'">('.$us_last['login'].')</a> </center></td>
<td width="33%"><center> <a href="/"><img src="/design/styles/'.htmlspecialchars($api_design).'/images/home.png"></a>  <a href="javascript:history.back()" onMouseOver="window.status="Назад";return true"><img src="/design/styles/'.htmlspecialchars($api_design).'/images/undo.png"></a> <a href="#top" id="top-link" title="Поднятся вверх"><img src="/design/styles/'.htmlspecialchars($api_design).'/images/up.png"></a> <a href="?'.$refr.'" title="Обновить страницу"><img src="/design/styles/'.htmlspecialchars($api_design).'/images/refresh.png"></a> </center></td>
<td width="33%"><center><a href="/modules/online.php">'.$onsite.'</a></center></td></tr></table></div>';
echo '<div class="loghead"><center><small>';
echo '<a href="http://apicms.ru"><font color="FFFFFF"> <strong>Управление сайтом ApiCMS</strong></a></br>';
echo date( "На сервере - d.m.y H:i" );
echo '</small></center></font></div>'.base64_decode($api_settings['counters']).'</body></html>';
////////////////////////////////////////
?>