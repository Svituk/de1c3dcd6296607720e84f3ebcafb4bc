<?php

$title = 'Выход из профиля'; // заголовок страницы
//////////////////////////////
require_once 'api_core/apicms_system.php';
//////////////////////////////
if (!$user['id']) header('location: /');

$act=htmlspecialchars(trim($_GET['act']));
//////////////////////////////
switch ($act){
case 'go_out':
setcookie('userlogin', $login);
setcookie('userpass', $pass);
session_destroy();
if (isset($_GET['return']))
header('Location: '.urldecode($_GET['return']));
else header("Location: /index.php?");
break;
default:
require_once 'design/styles/'.htmlspecialchars($api_design).'/head.php';
echo "<div class='apicms_subhead'><center><img src='/design/styles/".htmlspecialchars($api_design)."/images/load.gif' alt=''></br> Сессия будет удалена, подтвердите свой выход или покиньте эту страницу!";
echo '<form action="/log_out.php?act=go_out" method="post">';
echo '<input value="Подтверждаю" style="width:95%;" type="submit"></center></form></div>';
require_once 'design/styles/'.htmlspecialchars($api_design).'/footer.php';
}
//////////////////////////////
?>