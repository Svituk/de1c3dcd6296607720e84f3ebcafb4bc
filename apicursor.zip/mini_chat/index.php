<?

/////////////////////////////////////////
$title = 'Мини чат APICMS';
require_once '../api_core/apicms_system.php';
require_once '../design/styles/'.htmlspecialchars($api_design).'/head.php';
/////////////////////////////////////////
if (isset($user['id']) && $_POST['txt']!=NULL){
$text = apicms_filter($_POST['txt']);
if (strlen($text)>1024)$err = '<div class="apicms_content"><center>Очень длинное сообщение</center></div>';
if (strlen($text)<10)$err = '<div class="apicms_content"><center>Короткое сообщение</center></div>';
if (!isset($err)){
global $connect;
mysqli_query($connect, "INSERT INTO `mini_chat` (`txt`, `id_user`, `time`) VALUES ('$text', '".intval($user['id'])."', '$time')");
////////////////////////////////////
$plus_fishka = $user['fishka'] + $api_settings['fishka_chat'];
mysqli_query($connect, "UPDATE `users` SET `fishka` = '$plus_fishka' WHERE `id` = '".intval($user['id'])."' LIMIT 1");
echo '<div class="erors"><center>Сообщение успешно добавлено</center></div>';
echo'<meta http-equiv="Refresh" apicms_content="0"; URL=index.php"/>';
////header("Location: index.php");
}else{
apicms_error($err);
}
}

/////////////////////////////////////////
global $connect;
$k_post_result = mysqli_query($connect, "SELECT COUNT(*) as cnt FROM `mini_chat`");
$k_post_row = mysqli_fetch_assoc($k_post_result);
$k_post = $k_post_row['cnt'];
$k_page=k_page($k_post,$api_settings['on_page']);
$page=page($k_page);
$start=$api_settings['on_page']*$page-$api_settings['on_page'];
if ($k_post==0)echo "<div class='erors'><center>Сообщений в мини-чате ненайдено</center></div>";
/////////////////////////////////////////
$qii=mysqli_query($connect, "SELECT * FROM `mini_chat` ORDER BY id DESC LIMIT $start, ".$api_settings['on_page']);
while ($post_chat = mysqli_fetch_assoc($qii)){
$ank2=mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM `users` WHERE `id` = ".intval($post_chat['id_user'])." LIMIT 1"));
echo '<div class="apicms_subhead"><table width="100%" ><tr><td width="20%"><center>';
echo apicms_ava32($ank2['id']);
echo "</center></td><td width='80%'><a href='/profile.php?id=$ank2[id]'>".$ank2['login']."</a> ";
echo "<span style='float:right'> ".apicms_data($post_chat['time'])." ";
if ($user['level']>=1) echo '  <a href="delete.php?id='.$post_chat['id'].'"><img src="/design/styles/'.htmlspecialchars($api_design).'/images/delete_us.png" alt="DEL"></a> ';
echo " </span>";
echo "</br> <b>".apicms_smiles(apicms_br(htmlspecialchars($post_chat['txt'])))."</b>";
if ($user['id']!=$ank2['id'] && $user['id']) echo '<br /><small><a href="otvet.php?id='.$post_chat['id'].'&user='.$ank2['id'].'">Ответить</a></small>';
echo '</td></tr></table></div>';
}
/////////////////////////////////////////
if ($user['id']){
echo "<form action='?ok' method='post'>";
echo "<div class='apicms_dialog'><center><textarea name='txt'></textarea><br />";
echo "<input type='submit' value='Добавить'/></form></center></div>";
}else{
echo "<div class='erors'>Извините вы неможете писать в чате</div>\n";
}
/////////////////////////////////////////
if ($k_page > 1){
echo '<div class="apicms_subhead"><center>';
str('?',$k_page,$page); // генерируем постраничную навигацию
echo '</center></div>';
}
require_once '../design/styles/'.htmlspecialchars($api_design).'/footer.php';
?>