<?php
// Database connection settings for ApiCMS
// Replace the placeholders below with your actual MySQL credentials.
// Example:
// define('DBHOST', 'localhost');
// define('DBUSER', 'my_db_user');
// define('DBPASS', 'my_db_password');
// define('DBNAME', 'my_database_name');

define('DBHOST', 'localhost');
define('DBUSER', 'f67172td_base');
define('DBPASS', 'svitu4ok!');
define('DBNAME', 'f67172td_base');

// Optional: You can protect this file with proper filesystem permissions so
// that the real credentials are not world-readable on the server.

?>